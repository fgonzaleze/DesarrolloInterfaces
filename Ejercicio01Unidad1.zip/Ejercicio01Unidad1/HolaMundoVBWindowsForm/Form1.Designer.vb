﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        BtnSaludar = New Button()
        TXTNombre = New TextBox()
        SuspendLayout()
        ' 
        ' BtnSaludar
        ' 
        BtnSaludar.Location = New Point(334, 185)
        BtnSaludar.Name = "BtnSaludar"
        BtnSaludar.Size = New Size(151, 75)
        BtnSaludar.TabIndex = 0
        BtnSaludar.Text = "Saludo"
        BtnSaludar.UseVisualStyleBackColor = True
        ' 
        ' TXTNombre
        ' 
        TXTNombre.Location = New Point(334, 266)
        TXTNombre.Name = "TXTNombre"
        TXTNombre.Size = New Size(149, 23)
        TXTNombre.TabIndex = 1
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(TXTNombre)
        Controls.Add(BtnSaludar)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents BtnSaludar As Button
    Friend WithEvents TXTNombre As TextBox
End Class
