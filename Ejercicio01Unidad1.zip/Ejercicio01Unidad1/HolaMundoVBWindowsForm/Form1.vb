﻿Public Class Form1
    Private Sub BtnSaludar_Click(sender As Object, e As EventArgs) Handles BtnSaludar.Click
        MessageBox.Show("Hola", "Saludo")

    End Sub
End Class
