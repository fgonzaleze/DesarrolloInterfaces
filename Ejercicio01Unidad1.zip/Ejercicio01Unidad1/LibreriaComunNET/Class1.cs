﻿namespace LibreriaComunNET
{
    public class Class1
    {

    }
}